#encoding: utf-8
from .common import ProgressBarBase
import sys


class ProgressBarTerminal(ProgressBarBase):

    def __init__(self,
                 iterable_or_max,
                 title='Progress', key=None, autohide=False, quiet=False,
                 format_str='%(title)s: %(percent).1f%% [%(bar)s] %(current).0f/%(max).0f [%(elapsed).1f s] [eta %(eta_avg).0f+-%(eta_stddev).0f s]',
                 width=80):
        super(ProgressBarTerminal, self).__init__(iterable_or_max, title, key, autohide, quiet)
        self.format_strs = format_str.split('%(bar)s')
        self.width = width
        self.phases = (' ', '▏', '▎', '▍', '▌', '▋', '▊', '▉', '█')

    def print_output(self):
        parts = []
        for format in self.format_strs:
            try:
                parts.append(format % self)
            except TypeError as E:
                print(E)
                print(format)
        parts[1:1] = self.bar(self.width - sum(map(len, parts)))
        if self.extra_text is not None:
            print(('\r' + ''.join(parts)).encode('utf-8'), self.extra_text.encode('utf-8'))
        else:
            print(('\r' + ''.join(parts)).encode('utf-8'))
        sys.stdout.flush()

    def start(self):
        super(ProgressBarTerminal, self).start()
        print()
        self.print_output()

    def advance(self, extra_text = None, **kwargs):
        super(ProgressBarTerminal, self).advance(extra_text = extra_text, **kwargs)
        self.print_output()

    def finish(self):
        super(ProgressBarTerminal, self).finish()
        if not self.autohide:
            print()

    def hide(self):
        super(ProgressBarTerminal, self).hide()
        print((' ' * self.width) + '\r',)
        sys.stdout.flush()

    def bar(self, bar_width):
        completely_filled = int(self.current * float(bar_width) / float(self.max))
        phase = (self.current * bar_width * len(self.phases) / self.max) % len(self.phases)

        return (self.phases[-1] * completely_filled +
                (self.phases[phase] if completely_filled < bar_width else self.phases[-1]) +
                self.phases[0] * (bar_width - completely_filled))

    def set_extra_text(self, text):
        super(ProgressBarTerminal, self).set_extra_text(text)
        self.print_output()
