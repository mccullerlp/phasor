from .terminal_bar import ProgressBarTerminal
from .ipynb_bar import ProgressBarIPyNb


def ProgressBar(iterable_or_max,
                title='Progress', key=None, autohide=False, quiet=False,
                width_term=80,
                **kwargs
                ):
    if in_ipynb():
        return ProgressBarIPyNb(
            iterable_or_max,
            title,
            key,
            autohide,
            quiet,
            **kwargs
        )
    else:
        return ProgressBarTerminal(
            iterable_or_max,
            title,
            key,
            autohide,
            quiet,
            width = width_term,
            **kwargs
        )


def in_ipynb():
    try:
        cfg = get_ipython().config
        if cfg['IPKernelApp']['parent_appname'] == 'ipython-notebook':
            return True
        else:
            return False
    except NameError:
        return False
