# -*- coding: utf-8 -*-
"""
"""
from __future__ import division, print_function

self              = 'self'
ports_list        = 'ports_list'
ports_bond        = 'ports_bond'
auto_terminate    = 'auto_terminate'
bond_completion   = 'bond_completion'
bond_delegate     = 'bond_delegate'
